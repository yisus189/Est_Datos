package co.edu.unipiloto.estdatos.tallergen.mundo;

public class Producto {

	protected double precio;

	public Producto(double pPrecio)
	{
		precio = pPrecio;
	}

}

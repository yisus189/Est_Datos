/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.estdatos.tallergen.mundo;

/**
 *
 * @author Jesus Bravo
 */
public class Computador extends Electronico{
    
    public enum OS
	{
		WINDOWS, MAC_OS, LINUX, OTRO
	}
    
    private OS Os;
   
    public static final String MARCA_HP= "HP";
    public static final String MARCA_ASUS = "Asus";
    public static final String MARCA_APPLE = "Apple";
    
    public enum MARCA
	{
		HP, ASUS, APPLE, OTRO
	}
    
    private MARCA marca;
    
    public Computador(OS pOs, MARCA Marca,Electronico.Gama pGama, double pPrecio) 
    {
        super(pGama, pPrecio);
        Os = pOs;
        marca = Marca;
    }
    
    public String toString()
	{
		return "Os: "+Os + " , marca: "+marca +", Gama:"+ gama +"($ "+precio + ")";
	} 
}
